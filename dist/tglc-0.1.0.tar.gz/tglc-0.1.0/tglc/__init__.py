__version__ = "0.1.0"
__author__ = 'Te Han'
__credits__ = 'University of California, Santa Barbara'
